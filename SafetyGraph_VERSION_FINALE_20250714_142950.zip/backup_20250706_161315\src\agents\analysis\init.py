"""
Agents d'Analyse SafeGraph
Module d'analyse des risques et détection d'écarts
"""

from .analyste_agent import analyste_agent

__all__ = ["analyste_agent"]