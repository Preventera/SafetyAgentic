"""
Agents de Recommandation SafeGraph
Module de génération de plans d'action et recommandations
"""

from .recommandation_agent import recommandation_agent

__all__ = ["recommandation_agent"]