"""
Agents d'Évaluation SafeGraph
Module de collecte et d'évaluation des données sécurité
"""

from .collecteur_agent import collecteur_agent

__all__ = ["collecteur_agent"]